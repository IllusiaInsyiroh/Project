/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas1;

/**
 *
 * @author windows
 */
interface demam {
     public void Batuk(); // interface method (does not have a body)
  public void Flu(); // interface method (does not have a body)
}
