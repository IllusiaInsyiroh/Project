/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java_attribute;

/**
 *
 * @author windows
 */
public class Mod_attribute {
  int x;

  public static void main(String[] args) {
    Mod_attribute myObj = new Mod_attribute();
    myObj.x = 40;
    System.out.println(myObj.x);
  }
}