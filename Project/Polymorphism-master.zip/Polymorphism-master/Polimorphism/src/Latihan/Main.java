/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

/**
 *
 * @author windows
 */

public class Main {
    public static void main(String[] args) {
    Keluarga myFamily = new Keluarga();  // Create a Animal object
    Keluarga j= new Ibu();
    Keluarga k= new Ayah();
    Keluarga l= new Adik();
    myFamily.bilang();
    j.bilang();
    k.bilang();
    l.bilang();

    }
    
}
