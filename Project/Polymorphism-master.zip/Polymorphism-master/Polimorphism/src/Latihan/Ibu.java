/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Latihan;

/**
 *
 * @author windows
 */
public class Ibu extends Keluarga{
      public void bilang(){
        System.out.println("Ibu berkata : makan dulu nak!");
    }
}
