/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Constructor;

/**
 *
 * @author windows
 */
public class Constructor {
       long nim;
    String jurusan, nama, alamat;
    int angkatan;
    public Constructor(){
    nim=201869040017L;
    nama="AVANUL ABDUL FATAH";
    alamat="GONDANG WETAN";
    jurusan="TEKNIK INFORMATIKA";
    angkatan=2018;
}
    /*
    public static void main (String[] args){
  Constuctor data=new Constuctor();
  //CONSTRACTOR
  System.out.println("===== CONTRUKTOR=====");
  System.out.print("NIM : "+data.nim+
                  "\nNAMA : "+data.nama+
                  "\nALAMAT : "+data.alamat+
                  "\nJURUSAN : "+data.jurusan+
                  "\nANGKATAN : "+data.angkatan+"\n");}
*/
}
